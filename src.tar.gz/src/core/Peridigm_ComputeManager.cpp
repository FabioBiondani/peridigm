//*! \file Peridigm_ComputeManager.cpp */
//@HEADER
// ************************************************************************
//
//                             Peridigm
//                 Copyright (2011) Sandia Corporation
//
// Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
// the U.S. Government retains certain rights in this software.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
// 1. Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright
// notice, this list of conditions and the following disclaimer in the
// documentation and/or other materials provided with the distribution.
//
// 3. Neither the name of the Corporation nor the names of the
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY SANDIA CORPORATION "AS IS" AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL SANDIA CORPORATION OR THE
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Questions?
// David J. Littlewood   djlittl@sandia.gov
// John A. Mitchell      jamitch@sandia.gov
// Michael L. Parks      mlparks@sandia.gov
// Stewart A. Silling    sasilli@sandia.gov
//
// ************************************************************************
//@HEADER

#include <vector>
#include <string>
#include <iostream>
#include <boost/algorithm/string.hpp>

#include "Peridigm_ServiceManager.hpp"
#include "Peridigm_ComputeManager.hpp"
#include "compute_includes.hpp"

using namespace std;

PeridigmNS::ComputeManager::ComputeManager( Teuchos::RCP<Teuchos::ParameterList> params, Teuchos::RCP<const Epetra_Comm> epetraComm, Teuchos::RCP<const Teuchos::ParameterList> computeClassGlobalParams ) {

  Teuchos::RCP<Compute> compute;

  // No input to validate; no computes requested
  if (params == Teuchos::null) return;

  // Create a list of the compute classes that will be built based on user-supplied compute class parameters.
  // If the name of one of these compute classes appears in both the compute class parameters ParameterList and
  // the output variables ParameterList, we want to only instantiate one object and we want to use the compute
  // class parameters (as opposed to an empty parameter list, which is what is done when creating compute objects
  // based on the output variables ParameterList).
  vector<string> computeClassParameterNames;
  if (params->isSublist("Compute Class Parameters")) {
    Teuchos::RCP<Teuchos::ParameterList> computeClassParameters = sublist(params, "Compute Class Parameters");
    for (Teuchos::ParameterList::ConstIterator it = computeClassParameters->begin(); it != computeClassParameters->end(); ++it) {
      TEUCHOS_TEST_FOR_EXCEPT_MSG(!computeClassParameters->isSublist(it->first),
				  "**** Error processing compute class parameters, expected ParameterList but found single entry.\n");
      const Teuchos::ParameterList& params = computeClassParameters->sublist(it->first);
      TEUCHOS_TEST_FOR_EXCEPT_MSG(!params.isParameter("Compute Class"),
				  "**** Error processing compute class parameters, expected \"Compute Class\" entry in ParameterList.\n");
      string computeClassName = params.get<string>("Compute Class");
      // Replace spaces with underscores
      while(boost::find_first(computeClassName," "))
	boost::replace_first(computeClassName," ","_");
      computeClassParameterNames.push_back(computeClassName);
    }
  }

  vector< pair<string, Teuchos::RCP<Teuchos::ParameterList> > > computeClassesToBuild;

  // Create compute classes based on requested output variables
  if (params->isSublist("Output Variables")) {
    Teuchos::RCP<Teuchos::ParameterList> outputVariables = sublist(params, "Output Variables");
    for (Teuchos::ParameterList::ConstIterator it = outputVariables->begin(); it != outputVariables->end(); ++it) {
      string name = it->first;
      while(boost::find_first(name," "))
	boost::replace_first(name," ","_");
      if( find(computeClassParameterNames.begin(), computeClassParameterNames.end(), name) == computeClassParameterNames.end() ){
        Teuchos::RCP<Teuchos::ParameterList> nullRcp;
        pair<string, Teuchos::RCP<Teuchos::ParameterList> > nameAndParamsPair(name, nullRcp);
        computeClassesToBuild.push_back(nameAndParamsPair);
      }
    }
  }

  // Create compute classes based on user-supplied compute class parameters
  if (params->isSublist("Compute Class Parameters")) {
    Teuchos::RCP<Teuchos::ParameterList> computeClassParameters = sublist(params, "Compute Class Parameters");
    for (Teuchos::ParameterList::ConstIterator it = computeClassParameters->begin(); it != computeClassParameters->end(); ++it) {
      string parameterListName = it->first;
      Teuchos::RCP<Teuchos::ParameterList> params = Teuchos::rcpFromRef( computeClassParameters->sublist(parameterListName) );
      string name = params->get<string>("Compute Class");
      while(boost::find_first(name," "))
	boost::replace_first(name," ","_");
      pair<string, Teuchos::RCP<Teuchos::ParameterList> > nameAndParamsPair(name, params);
      computeClassesToBuild.push_back(nameAndParamsPair);
    }
  }

  // Instantiate the compute classes
  vector< pair<string, Teuchos::RCP<Teuchos::ParameterList> > >::iterator it;
  for (it = computeClassesToBuild.begin() ; it != computeClassesToBuild.end() ; it++) {
    string name = it->first;
    Teuchos::RCP<Teuchos::ParameterList> params = it->second;
    #define COMPUTE_CLASS
      #define ComputeClass(key, Class) \
      if (name == #key) { \
        compute = Teuchos::rcp( new PeridigmNS::Class(params, epetraComm, computeClassGlobalParams) ); \
        computeObjects.push_back( Teuchos::rcp_implicit_cast<Compute>(compute) ); \
      }
      #include "compute_includes.hpp"
    #undef  COMPUTE_CLASS
  }
}

Teuchos::ParameterList PeridigmNS::ComputeManager::getValidParameterList() {
  Teuchos::ParameterList validParameterList("Output");
  return validParameterList;
}

vector<int> PeridigmNS::ComputeManager::FieldIds() const {

  vector<int> myFieldIds;

  // Loop over all compute objects, collect the field ids they compute
  for (unsigned int i=0; i < computeObjects.size(); i++) {
    Teuchos::RCP<const PeridigmNS::Compute> compute = computeObjects[i];
    vector<int> computeFieldIds = compute->FieldIds();
    myFieldIds.insert(myFieldIds.end(), computeFieldIds.begin(), computeFieldIds.end());
  }

  // remove duplicates
  sort(myFieldIds.begin(), myFieldIds.end());
  vector<int>::iterator newEnd = unique(myFieldIds.begin(), myFieldIds.end());
  myFieldIds.erase(newEnd, myFieldIds.end());

  return myFieldIds;
}

set<PeridigmNS::PeridigmService::Service> PeridigmNS::ComputeManager::Services() const {

  set<PeridigmNS::PeridigmService::Service> requestedServices;

  // Loop over all compute objects, collect the services they request
  for (unsigned int i=0; i < computeObjects.size(); i++) {
    Teuchos::RCP<const PeridigmNS::Compute> compute = computeObjects[i];
    set<PeridigmNS::PeridigmService::Service> computeServices = compute->Services();
    requestedServices.insert(computeServices.begin(), computeServices.end());
  }

  return requestedServices;
}


PeridigmNS::ComputeManager::~ComputeManager() {
}

void PeridigmNS::ComputeManager::initialize(Teuchos::RCP< vector<PeridigmNS::Block> > blocks) {

  // \todo Identify what the desired behavior is for compute classes and multiple blocks!
  //       Calling initialize on each block individually may not make sense.

  for(unsigned int i=0 ; i<computeObjects.size() ; ++i){
     computeObjects[i]->initialize(blocks);
  }

}

void PeridigmNS::ComputeManager::pre_compute(Teuchos::RCP< vector<PeridigmNS::Block> > blocks) {

  // \todo Identify what the desired behavior is for compute classes and multiple blocks!

  for(unsigned int i=0 ; i<computeObjects.size() ; ++i){
     computeObjects[i]->pre_compute(blocks);
  }
}


void PeridigmNS::ComputeManager::compute(Teuchos::RCP< vector<PeridigmNS::Block> > blocks) {

  // \todo Identify what the desired behavior is for compute classes and multiple blocks!

  for(unsigned int i=0 ; i<computeObjects.size() ; ++i){
     computeObjects[i]->compute(blocks);
  }

}
